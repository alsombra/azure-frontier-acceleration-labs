# Revisao limitada de inclusao - candidato fontes H2 v2

Revisao tecnica local em 07/11/2026, nao parecer juridico, licenca ou aceite
de terceiros. Candidato preparado, nao publicado nem liberado para producao.

## Inventario efetivamente entregue

50 arquivos: 36 fontes Java (30 principais e 6 testes), pom.xml, quatro scripts
PowerShell, seis configuracoes XML/properties, README.md, este aviso e
MANIFESTO.json. O manifesto registra tamanho e SHA256 dos outros 49 arquivos.
Nenhum JAR, class, DLL, executavel, JDK, Maven, target, runtime, log ou arquivo
compactado integra o ZIP. O inventario de 142 bibliotecas dos kits binarios
anteriores nao e o inventario deste candidato.

## Inspecao e indicacoes encontradas

Foram inspecionados os arquivos da allowlist: fontes Java, POM, configuracoes,
scripts e guia. A varredura textual procurou copyright, LICENSE/NOTICE, SPDX,
origem copiada/adaptada, links, chaves privadas, tokens conhecidos, senhas de
datasource nao vazias e configuracao Oracle externa. Nao foram encontrados
arquivos LICENSE/NOTICE nem cabecalhos de copyright/licenca nos fontes e
controles originais incluidos. Nao se identificou indicacao explicita de
snippet copiado ou implementacao vendorizada. Ausencia de indicacao nao
comprova autoria, proveniencia ou inexistencia de obrigacao de atribuicao.

Os imports Spring/JPA/JUnit/Mockito e as chamadas sun.misc.BASE64Encoder e
BASE64Decoder referenciam APIs, nao incluem suas implementacoes. O comentario
em PasswordEncoder menciona sun.misc; esse uso obsoleto permanece didatico.
Os XML referenciam schemas W3C/Maven. logback-spring.xml inclui por referencia
org/springframework/boot/logging/logback/base.xml, sem copiar esse recurso.
Links Maven Central, downloads oficiais e HTTP loopback sao referencias.
O teste PasswordEncoderTest usa uma string sintetica, nao uma credencial real.
Datasource H2 usa sa com senha vazia, somente em memoria local descartavel.

O POM declara Spring Boot 1.5.22.RELEASE, starters, H2, Lombok, Jackson,
Log4j, Commons e plugins Maven/JaCoCo. Essas declaracoes nao redistribuem
os respectivos JARs. Maven resolve dependencias separadamente; quem baixar,
usar ou redistribuir binarios deve conferir os termos das versoes exatas,
transitivas, recursos incorporados e ferramentas. Nenhuma licenca dessas
bibliotecas foi assumida, aceita ou substituida por este aviso.

## Limites e pendencias

A declaracao do usuario atribui a titularidade a Microsoft e autoriza fontes
ao cliente participante deste laboratorio. Nao e confirmacao corporativa ou
juridica independente, documento assinado, licenca publica/open source,
autorizacao de binarios ou aceite de terceiros. Termos especificos de entrega,
responsavel, canal institucional e eventual aceite de revisao seguem pendentes.
Nao foram adicionados texto de licenca Microsoft, copyright ou assinatura.
Publicacao publica e redistribuicao irrestrita nao estao autorizadas.

Esta inspecao heuristica nao verifica similaridade contra codigo externo,
cadeia de autoria, todas as formas de segredo, CVEs, licencas de dependencias
baixadas ou conformidade juridica integral. Hash comprova integridade, nao
origem, seguranca ou licenca. As evidencias internas nao integram a entrega.

Os 36 Java permanecem identicos ao candidato anterior. Tickets continua com
SYSDATE - :diasAtras, falha H2 historica 50004/HY004 e HTTP500; nao corrigida
nem retestada neste escopo. Os testes existentes e o fluxo HTTP de ferias nao
demonstram que toda a aplicacao esteja funcional ou apta a producao.