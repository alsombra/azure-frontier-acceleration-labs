# Contoso RH - candidato educacional de fontes H2

**NAO USAR EM PRODUCAO. NAO PUBLICADO.** O usuario declarou titularidade
Microsoft e autorizou distribuicao ao cliente para este laboratorio em
07/11/2026. Termos especificos de entrega ainda pendentes; esta declaracao nao
concede licenca open source, publicacao publica ou liberacao de terceiros.

Java 8 / Spring Boot 1.5.22.RELEASE preservados para ensino. Dependencias
obsoletas e avisos sun.misc permanecem; nao houve modernizacao nem auditoria
de seguranca. O driver ojdbc8 foi removido somente deste candidato. Maven resolve
dependencias separadamente; o ZIP nao inclui JDK, Maven, bibliotecas ou JARs.
As dependencias baixadas pelo Maven conservam suas proprias licencas.
Gratuidade nao dispensa conferir os termos dos arquivos efetivamente entregues.

## Ferramentas gratuitas, sem trial

Para este legado, baixe um JDK8 completo Eclipse Temurin no site oficial:
https://adoptium.net/temurin/releases/?version=8. Escolha Windows, JDK e a
arquitetura da sua maquina; nao escolha apenas JRE. Nao empacotamos o JDK.

Baixe Maven 3.9.x Binary zip archive em https://maven.apache.org/download.cgi.
Extraia os dois produtos e informe os caminhos nos comandos abaixo. A primeira
compilacao precisa de internet para baixar dependencias dos repositorios Maven.
Proxy e politicas corporativas podem exigir configuracao propria; nao desabilite
validacao TLS nem compartilhe credenciais em comandos ou capturas de tela.

Java21 pertence a etapa modernizada, nao substitui o JDK8 deste legado.
Download oficial: https://learn.microsoft.com/java/openjdk/download.
Este pacote contem apenas o legado H2, nao o resultado modernizado.
H2 em memoria dispensa instalar Oracle ou contratar servico de banco.
Servicos Azure e acesso ao Copilot nao estao incluidos nessa gratuidade.

## Execucao local Windows PowerShell 5.1

Use JDK8 completo e Maven3.9.x existentes. Informe seus caminhos locais:

```powershell
.\build.ps1 -JavaHome '<raiz-do-JDK8>' -MavenCommand '<caminho-do-mvn.cmd>'
.\start.ps1 -JavaHome '<raiz-do-JDK8>'
.\bootstrap.ps1
.\stop.ps1
```

O build cria target, JAR, checksum e evidencias somente na copia de trabalho.
Nao os redistribua como se fossem fontes. Nao execute pela extensao Java ou
spring-boot:run sem os controles locais. start.ps1 fixa H2 em memoria,
create-drop, usuario sintetico sa/senha vazia, inicializacao SQL desabilitada,
127.0.0.1:18081, management.port=-1, endpoints e console H2 desabilitados.
Nao ha banco externo. MODE=Oracle e compatibilidade SQL do H2, nao driver Oracle.
Scripts recusam injecao de configuracao de ambiente e porta ocupada.

Para outra porta, passe o mesmo -Port para start.ps1 e bootstrap.ps1. Espere
o sinal Started em runtime/stdout.log antes de executar o bootstrap. Consulte
http://127.0.0.1:18081/api/ferias/funcionario/1. Logs locais e registro PID ficam
em runtime; stop.ps1 verifica identidade e aguarda o encerramento do PID proprio.
Execute stop.ps1 mesmo se o bootstrap falhar. Dados H2 sao descartados ao parar.

## Limites didaticos conhecidos

Bootstrap usa somente dados ficticios: funcionarioId 1, inicio 1798761600000,
10 dias, status SOLICITADA; GET vazio -> POST -> GET do registro. Recusa repetir
em banco nao vazio. Os 12 testes existentes nao cobrem todas as consultas nativas.
TicketRepository usa SYSDATE - :diasAtras: incompatibilidade conhecida com H2,
historicamente reproduzida como 50004/HY004 e HTTP500. Nao foi corrigida aqui.
Outras consultas Oracle/PLSQL permanecem como objeto do laboratorio, sem promessa
de compatibilidade integral. Nao inserir dados pessoais ou conectar banco real.

MANIFESTO.json lista SHA256 e tamanho de cada arquivo, exceto o proprio manifesto.
O checksum externo autentica integridade do ZIP, nao origem, licenca ou seguranca.