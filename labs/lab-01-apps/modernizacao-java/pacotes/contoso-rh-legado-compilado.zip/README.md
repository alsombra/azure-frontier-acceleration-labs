# Contoso RH: legado Java local

Pacote didatico Windows / PowerShell 5.1. Requer Java 8 x64 ja instalado; nao inclui nem instala runtime. Nao usar em producao, rede compartilhada ou com dados reais. O legado nao foi modernizado nem certificado como seguro.

## Executar

Extraia todo o ZIP, abra PowerShell na pasta extraida e substitua o caminho abaixo pelo seu Java 8:

```powershell
.\start.ps1 -JavaHome 'C:\caminho\jdk8'
Get-Content .\runtime\stdout.log -Tail 20
```

Aguarde o log indicar `Started ContosoRhApplication`. O script inicia processo em segundo plano; mantenha a pasta no mesmo lugar ate encerrar. Nao execute `java -jar` diretamente nem altere os controles de isolamento. Politicas corporativas de execucao devem ser respeitadas; nao e necessario desativa-las globalmente.

O banco inicia vazio. Crie o exemplo ficticio pela API existente:

```powershell
.\bootstrap.ps1
Invoke-RestMethod 'http://127.0.0.1:18081/api/ferias/funcionario/1'
.\stop.ps1
```

URL da demonstracao: http://127.0.0.1:18081/api/ferias/funcionario/1 . So responde enquanto o processo esta executando. E uma API JSON: nao existe tela de colaboradores nem interface web neste pacote.

Bootstrap: GET inicial vazio; POST `/api/ferias?funcId=1&inicio=1798761600000&dias=10`; GET com id 1, funcionarioId 1, 10 dias, status SOLICITADA, inicio 2027-01-01 UTC e fim 2027-01-11 UTC. `funcId` e apenas o identificador sintetico aceito pelo legado; nao cria cadastro nem dados pessoais. O calculo original adiciona 10 dias a data inicial, sem reinterpretar regras de negocio.

O bootstrap recusa repeticao com registros existentes. Para repetir, encerre e inicie novamente: os dados sao descartados. Evidencia da chamada fica em `runtime/http.json`. Logs ficam em `runtime/stdout.log` e `runtime/stderr.log`. `stop.ps1` somente encerra o PID registrado se horario de criacao e JAR coincidirem; nunca procura nem mata todos os processos Java.

Se 18081 estiver ocupada, `start.ps1` falha antes de iniciar. Escolha outra porta com `-Port 18082` e use o mesmo parametro no bootstrap e na URL. Nao encerre o processo que ocupa a porta. `stop.ps1` usa o registro do proprio pacote, sem precisar informar porta.

## Controles

- Java 8 explicito, configuracao externa local e overrides JVM fixos; variaveis de injecao Spring/Java sao recusadas pelo launcher.
- H2 em memoria, usuario sa e senha vazia, driver/dialect H2, create-drop; nenhum Oracle, Azure ou servico externo e necessario em runtime.
- HTTP somente 127.0.0.1; management desabilitado, endpoints Actuator e console H2 desabilitados, inicializacao SQL Spring desabilitada. SQL Oracle nao e distribuido.
- SHA256 do JAR verificado antes de iniciar. Checksums detectam alteracao acidental, nao sao assinatura de confianca.
- Configuracoes Oracle originais foram substituidas apenas na copia preparada; Java e POM permanecem identicos ao legado original.

## Fontes E Limites

O ZIP de fontes correspondente fica ao lado do ZIP compilado, na pasta de distribuicao `pacotes`. Na pasta de fontes extraida:

```powershell
.\build.ps1 -JavaHome 'C:\caminho\jdk8' -MavenCommand 'C:\caminho\maven\bin\mvn.cmd'
.\start.ps1 -JavaHome 'C:\caminho\jdk8'
```

Build exige JDK 8 completo, Maven 3.9.x e acesso a Maven Central publica se faltarem dependencias. Nao usa settings corporativos. Resultado em `contoso-rh.jar`, checksum e `evidencias-build`; requer novamente bootstrap apos iniciar. Nenhum compilado antigo foi usado para gerar a entrega.

Os testes existentes e a demonstracao de ferias nao certificam todas as APIs nem equivalencia Oracle. A consulta de tickets com `SYSDATE - :diasAtras` tem incompatibilidade H2 historica documentada, nao corrigida nem revalidada aqui. `/ultimas` e as demais APIs nao sao criterios de aceite deste pacote. Nao ha autenticacao de negocio adicionada: loopback reduz exposicao, nao impede outros processos/usuarios locais. Dependencias antigas, avisos de API interna sun.misc e riscos do legado permanecem para a modernizacao; comentarios de CVE no POM nao constituem assessment verificado.

JDK e Maven nao sao redistribuidos. Dependencias permanecem embutidas conforme o POM e seus avisos/licencas internos; nao foi realizada auditoria juridica de redistribuicao nem varredura CVE nesta atividade. Validacao Windows local nao implica suporte Linux/macOS, ARM64 ou outras versoes de Java.

O proximo trabalho deve partir de outra copia dos fontes, preservar este baseline e repetir o mesmo POST/GET de ferias. Nenhuma modernizacao ou alteracao de portal faz parte desta entrega.

## Evidencia Local

Em 06/11/2026, build limpo com Maven 3.9.9 e Zulu OpenJDK 1.8.0_512: 12 testes, zero falhas, erros ou ignorados. JAR Boot inspecionado com 179 entradas, sem configuracao Oracle e sem SQL Oracle. HTTP real em pasta extraida com espacos: GET inicial 200 vazio, POST 200 e GET 200 com o registro ficticio descrito acima. Bind exclusivo 127.0.0.1:18081; `/env`, `/configprops`, `/health`, `/h2-console` e `/` retornaram 404. Bootstrap duplicado e porta ocupada foram recusados. Evidencias JSON/texto e SHA256 acompanham o pacote. Os numeros comprovam somente este recorte local, nao seguranca integral ou compatibilidade Oracle.