# Contoso RH Modernizado

AZURE DAY - Azure Frontier Acceleration. Execucao local, API JSON, dados sinteticos e H2 somente em memoria. Nao existe tela de colaboradores. Java nao acompanha o pacote.

## Requisitos E Build

Windows PowerShell 5.1, JDK 21 completo e Maven 3.9.x. Os caminhos sao parametros locais, sem configuracao global. Scripts validados em Windows e diretorios com espacos; portabilidade Linux/macOS nao foi certificada.

```powershell
.\build.ps1 -JavaHome 'C:\caminho\jdk21' -MavenCommand 'C:\caminho\maven\bin\mvn.cmd'
```

O padrao executa `clean verify`, compila producao/testes, roda toda a suite e gera JaCoCo. Usa somente Maven Central publica, com settings locais. Pode baixar dependencias publicas, sem login. Opcoes de verificacao: `-Goal test-compile`, `-Goal test`, `-Goal package`, `-Goal verify`; `-TestPattern 'TicketRepositoryTest,TicketServiceTest'` restringe casos, nao substitui a suite final. Nao use diretorio sincronizado que bloqueie `target`; extraia em pasta local com espacos. Fonte nao inclui JAR/target; o build cria JAR e SHA256.

## Start, Bootstrap E Stop

```powershell
.\start.ps1 -JavaHome 'C:\caminho\jdk21' -Port 18082
Get-Content .\runtime\stdout.log -Tail 20
```

Aguarde `Started ContosoRhApplication`. Entao:

```powershell
.\bootstrap.ps1 -Port 18082
Invoke-RestMethod 'http://127.0.0.1:18082/api/ferias/funcionario/1'
.\stop.ps1
```

O bootstrap exige banco vazio para funcionario1 e processo registrado pertencente ao pacote. POST real: `/api/ferias?funcId=1&inicio=1798761600000&dias=10`. Resultado: id1, funcionarioId1, dias10, statusSOLICITADA, dataInicio1798761600000 e dataFim1799625600000. Datas JSON sao numeros inteiros epoch milliseconds, como no legado, nao strings ISO. GET confirma exatamente os mesmos seis campos e valores. A configuracao global do mapper Boot4/Jackson3 restaura timestamps para java.util.Date e java.sql.Date, sem mudar controllers nem calculos.

Porta padrao dos scripts:18081; exemplo acima usa18082 para separar do legado. Listener exclusivamente127.0.0.1. Nao exponha em rede. Dados H2 descartados ao stop. Nao ha autenticacao de negocio adicionada; outros processos locais podem acessar a API. Use apenas dados sinteticos.

Scripts recusam variaveis de injecao JVM/Spring, Java errado, JAR com hash divergente, porta ocupada e operacoes concorrentes no mesmo diretorio. O lock `.operation.lock` usa handle exclusivo e pode permanecer vazio apos uso. Registro existente exige stop; stop verifica PID, instante de inicio e caminho do JAR antes de encerrar. Nunca remova um registro para forcar parada de outro processo.

## Integridade E Limites

Confira SHA256 externo do ZIP e manifesto interno antes de executar. Eles detectam alteracao acidental, nao sao assinatura nem prova de origem confiavel. Nao altere os ZIPs legados.

- Boot4.0.9 e Java21; suporte OSS da linha4.0 consultado em2026-11-07, ate2026-12. Reavalie suporte antes de uso futuro.
- Legado:12 testes; modernizado:18 testes, incluindo quatro regressoes Tickets e dois testes do contrato JSON/mapper. Evidencias finais ficam no diretorio de pacotes, fora dos ZIPs fechados.
- Tickets deixou de usar `SYSDATE - :diasAtras`; corte agora calculado pelo relogio UTC da aplicacao e passado como timestamp JPQL. H2Oracle antes falhava com `TIMESTAMP - UNKNOWN`; teste vermelho foi registrado. Oracle real nao foi testado.
- GET ferias/ultimas validado para a fixture de janeiro2027: vazio antes de dataInicio, conforme filtro por data atual. Outras consultas e Oracle real nao certificados; H2 MODE=Oracle nao certifica Oracle.
- Base64 reversivel continua sendo comportamento didatico legado, nao hashing seguro de senha. Nao use para credenciais reais.
- Nenhuma garantia de ausencia total de CVEs/segredos, auditoria juridica ou reproducibilidade integral. Comparacao bytecode cobre classes da aplicacao; JAR completo pode diferir por timestamps.
- Logs locais de build/runtime podem conter caminhos privados. Nao os publique. Veja CHANGELOG.md e REDISTRIBUICAO.md.