# Antes E Depois

AZURE DAY - Azure Frontier Acceleration, Contoso RH, 2026-11-07.

| Area | Antes preservado | Depois local |
| --- | --- | --- |
| Runtime | Zulu Java8u512 | Microsoft OpenJDK21.0.8 |
| Framework | Boot1.5.22.RELEASE | Ponte WIP3.5.16 validada, depois Boot4.0.9 OSS suportado na data da consulta |
| Persistencia | javax.persistence / Hibernate legado | Jakarta / Hibernate gerenciado pelo Boot4 BOM |
| JSON | Date como numeros epoch milliseconds | Jackson3 com customizador global WRITE_DATES_AS_TIMESTAMPS; mesmos tipos/valores e seis campos no POST/GET |
| Base64 | sun.misc encoder/decoder | java.util.Base64 no WIP; comportamento reversivel preservado, nao seguranca de senha |
| Tickets | SYSDATE menos parametro falha no H2Oracle | JPQL com timestamp parametrizado e Clock UTC testavel |
| Testes | 12 baseline | 18: todos os12 existentes, repository1 e service3 Tickets, dois testes JSON/mapper |
| Scripts | Java8 e propriedades administrativas antigas | Java21 explicito, H2mem/loopback, propriedades Boot atuais, locks, PID proprio e hashes |

O WIP ja existia com Java21/Jakarta/Base64; nao se atribui aqui execucao historica de etapas intermediarias anteriores. Foram realmente executados baseline8, ponte3.5.16 e alvo4.0.9. Nenhum original/ZIP legado foi corrigido ou substituido.

Regressoes Tickets: erro nativo H2Oracle reproduzido antes da correcao; fronteira inclusiva e exclusao de outro funcionario; corte30dias com relogio fixo; dias0/negativos; abertura preservando campos sinteticos e instante. O instante de corte agora vem da aplicacao UTC, nao do relogio do banco. Nenhuma equivalencia Oracle real e alegada.

Falhas de validacao registradas: H2 sem MODEOracle primeiro nao reconheceuSYSDATE; modoOracle reproduziuTIMESTAMP-UNKNOWN; clean no OneDrive bloqueou target, copia temporaria compilou; PowerShell tratava stderrMockito como excecao, corrigido usando exitcode sem ocultar avisos; primeiro checkHTTP Tickets usou rota errada405, corrigido no validador. POST/GETferias e cleanup ja passaram nessa tentativa.

Demais comportamentos nao foram reescritos. PasswordEncoder continua Base64 reversivel e consultas Oracle restantes continuam fora da certificacao local. Nenhum deployment, JDK empacotado, branch, commit ou push.

Correcao posterior da regressao JSON: entrega anterior retornava strings ISO; a opcao DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS foi confirmada nos JARs locais Boot4/Jackson3 e habilitada via JsonMapperBuilderCustomizer. Testes e bootstrap exigem numeros1798761600000/1799625600000, nao conversao tolerante de ISO. GET ultimas respeita filtro temporal e nao inclui a fixture futura antes de2027; nenhum negocio alterado. Avisos JVM de autoanexoMockito permanecem visiveis, sem supressao; sem avisos de compilacao.