# Revisao Local De Redistribuicao

Entrega privada local: AZURE DAY - Azure Frontier Acceleration, Contoso RH. Nao houve publicacao externa.

Fonte exclui JAR/target, runtime, logs Maven, .git, historico de upgrade e configuracoes/SQL Oracle originais. Compilado inclui somente JAR recem-construido, scripts, H2mem, documentacao e evidencias curadas. Nenhum JDK, instalador, DLL externo, chave ou credencial real deve ser incluido.

Banco usa usuarioH2sa e senha vazia em memoria; o fixture `senha-secreta-123` e sintetico, nao credencial. Scripts aceitam caminhosJavaHome/Maven do participante; nao trazem caminhos da maquina do autor. API nao deve receber dados pessoais/reais.

O JAR executavel preserva os avisos de licenca/NOTICE de dependencias em seus JARs internos. Inventario gerado em `evidencias/dependency-notices.json` lista cada biblioteca, SHA256 e avisos presentes; avisos extraidos, quando existentes, ficam em `notices`. Ausencia de aviso embutido em uma biblioteca nao prova ausencia de obrigacoes: conferir licenca publicada e regras corporativas antes de redistribuir externamente. Nao se atribui nova licenca ao codigo Contoso do repositorio.

Inspecao textual e de entradas de ZIP/JAR e limitada aos padroes registrados em evidencias; nao e auditoria juridica, antimalware, CVE completa ou garantia total de ausencia de segredos. Os manifestos nao sao assinaturas. Compilado inclui bibliotecas de terceiros, nao runtimeJava. Evidencias fechadas precedem a revalidacao final externa dosZIPs; nao alterar ZIP para inserir resultados posteriores.